#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <openssl/sha.h>

#define SHA_DIGEST_LENGTH 20

unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);

#pragma pack(push,1)
typedef struct BootEntry {
  unsigned char  BS_jmpBoot[3];     // Assembly instruction to jump to boot code
  unsigned char  BS_OEMName[8];     // OEM Name in ASCII
  unsigned short BPB_BytsPerSec;    // Bytes per sector. Allowed values include 512, 1024, 2048, and 4096
  unsigned char  BPB_SecPerClus;    // Sectors per cluster (data unit). Allowed values are powers of 2, but the cluster size must be 32KB or smaller
  unsigned short BPB_RsvdSecCnt;    // Size in sectors of the reserved area
  unsigned char  BPB_NumFATs;       // Number of FATs
  unsigned short BPB_RootEntCnt;    // Maximum number of files in the root directory for FAT12 and FAT16. This is 0 for FAT32
  unsigned short BPB_TotSec16;      // 16-bit value of number of sectors in file system
  unsigned char  BPB_Media;         // Media type
  unsigned short BPB_FATSz16;       // 16-bit size in sectors of each FAT for FAT12 and FAT16. For FAT32, this field is 0
  unsigned short BPB_SecPerTrk;     // Sectors per track of storage device
  unsigned short BPB_NumHeads;      // Number of heads in storage device
  unsigned int   BPB_HiddSec;       // Number of sectors before the start of partition
  unsigned int   BPB_TotSec32;      // 32-bit value of number of sectors in file system. Either this value or the 16-bit value above must be 0
  unsigned int   BPB_FATSz32;       // 32-bit size in sectors of one FAT
  unsigned short BPB_ExtFlags;      // A flag for FAT
  unsigned short BPB_FSVer;         // The major and minor version number
  unsigned int   BPB_RootClus;      // Cluster where the root directory can be found
  unsigned short BPB_FSInfo;        // Sector where FSINFO structure can be found
  unsigned short BPB_BkBootSec;     // Sector where backup copy of boot sector is located
  unsigned char  BPB_Reserved[12];  // Reserved
  unsigned char  BS_DrvNum;         // BIOS INT13h drive number
  unsigned char  BS_Reserved1;      // Not used
  unsigned char  BS_BootSig;        // Extended boot signature to identify if the next three values are valid
  unsigned int   BS_VolID;          // Volume serial number
  unsigned char  BS_VolLab[11];     // Volume label in ASCII. User defines when creating the file system
  unsigned char  BS_FilSysType[8];  // File system type label in ASCII
} BootEntry;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct DirEntry {
  unsigned char  DIR_Name[11];      // File name
  unsigned char  DIR_Attr;          // File attributes
  unsigned char  DIR_NTRes;         // Reserved
  unsigned char  DIR_CrtTimeTenth;  // Created time (tenths of second)
  unsigned short DIR_CrtTime;       // Created time (hours, minutes, seconds)
  unsigned short DIR_CrtDate;       // Created day
  unsigned short DIR_LstAccDate;    // Accessed day
  unsigned short DIR_FstClusHI;     // High 2 bytes of the first cluster address
  unsigned short DIR_WrtTime;       // Written time (hours, minutes, seconds
  unsigned short DIR_WrtDate;       // Written day
  unsigned short DIR_FstClusLO;     // Low 2 bytes of the first cluster address
  unsigned int   DIR_FileSize;      // File size in bytes. (0 for directories)
} DirEntry;
#pragma pack(pop)

void print_usage(){
    printf( "Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a contiguous file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
}

bool endOfClust(unsigned int clusterNumber){
    return clusterNumber >= 0x0FFFFFF8;
}

unsigned int readFat(FILE * disk, BootEntry bootEntry, unsigned int clustNum){

    unsigned int off = (clustNum) * 4;
    //printf("off is %d\n", off);
    unsigned int fatSec = bootEntry.BPB_RsvdSecCnt + (off / bootEntry.BPB_BytsPerSec);
    //printf("fatSec is %d\n", fatSec);
    unsigned int fatOff = off % bootEntry.BPB_BytsPerSec;
    //printf("fatOff is %d\n", fatOff);
    //int clustSize = fileSize/(bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus)+(fileSize%(bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus)!=0);
    long fatEntPosition = (fatSec * bootEntry.BPB_BytsPerSec) + fatOff;

    fseek(disk, fatEntPosition, SEEK_SET);
    //printf("seek set to %ld\n", fatEntPosition);

    unsigned int fatEnt;
    fread(&fatEnt, sizeof(fatEnt), 1, disk);
    //printf("fatEnt is %d\n", fatEnt);
    fatEnt &= 0x0FFFFFFF;
    //printf("fatEnt is %d\n", fatEnt);
    //MAYBE ITS BECAUSE ITS A LOCAL VARIABLE FATENT

    //returns address of next cluster
    return fatEnt;
}

unsigned char * readClust(FILE * fp,BootEntry bootEntry, unsigned int clustNum){
    unsigned int sect = (bootEntry.BPB_RsvdSecCnt)+(bootEntry.BPB_NumFATs*bootEntry.BPB_FATSz32); //calcualtes reserved sectors + fat area
    unsigned int clustSect = ((clustNum-2)*bootEntry.BPB_SecPerClus)+sect;
    unsigned int clustBytes = bootEntry.BPB_SecPerClus * bootEntry.BPB_BytsPerSec;

    unsigned char * clustBuff = malloc(clustBytes);
    if (clustBuff == NULL){
        printf("Error: Cannot allocate memory.\n");
        fclose(fp);
        exit(1);
    }

    fseek(fp, clustSect*bootEntry.BPB_BytsPerSec, SEEK_SET);
    fread(clustBuff, clustBytes, 1, fp);

    return clustBuff;
}

unsigned int combAdd(unsigned short hi, unsigned short lo){
    unsigned int combined = hi;
    combined <<= 16;
    combined |= lo;
    return combined;
}


void print_fs(FILE * fp){
    BootEntry bootEntry;

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }

    fclose(fp);
    printf("Number of FATs = %d\n", bootEntry.BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", bootEntry.BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n", bootEntry.BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", bootEntry.BPB_RsvdSecCnt);
}

void formatName(char * formatted, unsigned char * raw){
    
    int end = 7;
    while (end >=0 && raw[end] == ' '){
        end--;
    }

    strncpy(formatted,(const char*) raw, end+1);
    formatted[end+1] = '\0';

    bool ext = false;
    for (int i = 8; i < 11; ++i){
        if (raw[i] != ' '){
            ext = true;
            break;
        }
    }

    if (ext){
        int extEnd = 10;
        while (extEnd >= 8 && raw[extEnd] == ' '){
            extEnd--;
        }
        strcat(formatted, ".");
        strncat(formatted, (const char*)raw+8, extEnd-7);
    }
}

void list_dir(FILE * fp){

    BootEntry bootEntry;

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }
    //printf("Sectors per cluster: %d\n", bootEntry.BPB_SecPerClus);
    //printf("Bytes per sector: %d\n", bootEntry.BPB_BytsPerSec);
    //init to start of the FAT area
    unsigned int rootClus = bootEntry.BPB_RootClus;
    //printf("Root cluster: %d\n", rootClus);

    //process
    int count = 0;
    while (!endOfClust(rootClus)&&rootClus>=0x00000002)
    {
        unsigned char* clustBuff = readClust(fp, bootEntry, rootClus);
        DirEntry * dirEntries = (DirEntry*)clustBuff;
        int entries = (bootEntry.BPB_BytsPerSec*bootEntry.BPB_SecPerClus) / sizeof(DirEntry); //THIS MAY NEED AN OFFSET CHECK, IF IT IS LARGER THAN THE BYTES PER SECTOR;
        for (int i = 0; i < entries; ++i){
            DirEntry dirEntry = dirEntries[i];
            if (dirEntry.DIR_Name[0] == 0x00){
                break;
            }else if (dirEntry.DIR_Name[0] == 0xE5){
                continue;
            }

            unsigned int startClus = combAdd(dirEntry.DIR_FstClusHI, dirEntry.DIR_FstClusLO);
            char format[11];
            formatName(format, dirEntry.DIR_Name);

            if ((dirEntry.DIR_Attr & 0x10) == 0x10){
                printf("%s/ (starting cluster = %u)\n", format, startClus);
            }
            else if (dirEntry.DIR_FileSize == 0){
                printf("%s (size = %d)\n", format,dirEntry.DIR_FileSize);
            }else{
                printf("%s (size = %d, starting cluster = %u)\n", format, dirEntry.DIR_FileSize, startClus);
            }
            count++;
        }
        free(clustBuff);
        rootClus = readFat(fp, bootEntry, rootClus);
    }
    

    printf("Total number of entries = %d\n", count);

    fclose(fp);
}

void updateFat(FILE *fp, BootEntry bootEntry, unsigned int clustNum, unsigned int nextClust){
    unsigned int off = clustNum * 4;
    unsigned int fatSec = bootEntry.BPB_RsvdSecCnt + (off / bootEntry.BPB_BytsPerSec);
    unsigned int fatOff = off % bootEntry.BPB_BytsPerSec;

    long fatEntPosition = (fatSec * bootEntry.BPB_BytsPerSec)+ fatOff;
    fseek(fp, fatEntPosition, SEEK_SET);

    unsigned int currentfatEnt;
    fread(&currentfatEnt, sizeof(currentfatEnt), 1, fp);

    currentfatEnt = (currentfatEnt & 0xF0000000) | (nextClust & 0x0FFFFFFF);

    fseek(fp, fatEntPosition, SEEK_SET);
    fwrite(&currentfatEnt, sizeof(currentfatEnt), 1, fp);
}

void recoverRegFiles(FILE *fp, char * filename){

    BootEntry bootEntry;

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }
    
    //init to start of the FAT area
    unsigned int rootClus = bootEntry.BPB_RootClus;
    int found = 0;
    unsigned int firstSectorOfCluster;
    long dirOffset;
    unsigned int startClus;
    unsigned int dir_fileSize;

    //process
    do {
        unsigned char* clustBuff = readClust(fp, bootEntry, rootClus);
        DirEntry * dirEntries = (DirEntry*)clustBuff;
        int entries = bootEntry.BPB_BytsPerSec / sizeof(DirEntry);

        for (int i = 0; i < entries; ++i){
            DirEntry dirEntry = dirEntries[i];
            if (dirEntry.DIR_Name[0] == 0x00){
                break;
            }else if (dirEntry.DIR_Name[0] == 0xE5){
                
                char name[11];
                formatName(name, dirEntry.DIR_Name);
                if (strcmp(name+1,filename+1)==0){
                    //IMPLEMENT WRITING/RECOVERING
                    found++;
                    if (found>1){
                        printf("%s: multiple candidates found\n", filename);
                        return;
                    }
                    firstSectorOfCluster = ((rootClus - 2) * bootEntry.BPB_SecPerClus) + bootEntry.BPB_RsvdSecCnt + 
                    (bootEntry.BPB_NumFATs * bootEntry.BPB_FATSz32);
                    dirOffset = (firstSectorOfCluster * bootEntry.BPB_BytsPerSec) + (i * sizeof(DirEntry));
                    startClus = combAdd(dirEntry.DIR_FstClusHI, dirEntry.DIR_FstClusLO);
                    dir_fileSize = dirEntry.DIR_FileSize;

                }
            }
        }
        free(clustBuff);
        rootClus = readFat(fp, bootEntry, rootClus);

    }while (!endOfClust(rootClus));

    if (found == 1){
        fseek(fp, dirOffset, SEEK_SET);
        fwrite(&filename[0],1,1,fp);

        

        if (dir_fileSize!=0){
        unsigned int fileSize = (dir_fileSize/bootEntry.BPB_BytsPerSec)/bootEntry.BPB_SecPerClus;
        for (int i = 0; i < fileSize; ++i){
            updateFat(fp, bootEntry, startClus, startClus+1);
            startClus++;
        }
        updateFat(fp, bootEntry, startClus, 0x0FFFFFFF);
        }

        printf("%s: successfully recovered\n", filename);
    }
    else if (found == 0){
        printf("%s: file not found\n", filename);
    }

    fclose(fp);
}

void shaRecover(FILE *fp, char * filename, const unsigned char * targetHash){
    BootEntry bootEntry;

    const char *emptyFileHash = "da39a3ee5e6b4b0d3255bfef95601890afd80709";

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }
    
    //init to start of the FAT area
    unsigned int rootClus = bootEntry.BPB_RootClus;
    int found = 0;
    unsigned int firstSectorOfCluster;
    long dirOffset;
    unsigned int startClus;
    unsigned int dir_fileSize;
    //printf("start rootClus: %d\n", rootClus);
    //printf("this bootEntry has %d sectors per cluster\n", bootEntry.BPB_SecPerClus);
    //printf("each sector has %d bytes\n", bootEntry.BPB_BytsPerSec);

    //process
    do {
        //printf("sippin tea in yo hood\n");
        unsigned char* clustBuff = readClust(fp, bootEntry, rootClus);
        DirEntry * dirEntries = (DirEntry*)clustBuff;
        int entries = bootEntry.BPB_BytsPerSec / sizeof(DirEntry);

        for (int i = 0; i < entries; ++i){
            DirEntry dirEntry = dirEntries[i];
            char name[11];
            formatName(name, dirEntry.DIR_Name);
            //printf("Filename: %s\t", name);
            //printf("fileSize: %d\t", dirEntry.DIR_FileSize);
            if (dirEntry.DIR_Name[0] == 0x00){
                break;
            }else if (dirEntry.DIR_Name[0] == 0xE5){
                char name[11];
                formatName(name, dirEntry.DIR_Name);
                if (strcmp(name+1,filename+1)!=0){
                    continue;
                }
                if (dirEntry.DIR_FileSize == 0){
                    if(strcmp((char *)targetHash, emptyFileHash)==0){
                        if (strcmp(name+1,filename+1)==0){
                            //IMPLEMENT WRITING/RECOVERING
                            found++;
                            firstSectorOfCluster = ((rootClus - 2) * bootEntry.BPB_SecPerClus) + bootEntry.BPB_RsvdSecCnt + 
                                                (bootEntry.BPB_NumFATs * bootEntry.BPB_FATSz32);
                            dirOffset = (firstSectorOfCluster * bootEntry.BPB_BytsPerSec) + (i * sizeof(DirEntry));
                            startClus = combAdd(dirEntry.DIR_FstClusHI, dirEntry.DIR_FstClusLO);
                            dir_fileSize = dirEntry.DIR_FileSize;
                            break;
                        }
                    }
                }
                startClus = combAdd(dirEntry.DIR_FstClusHI, dirEntry.DIR_FstClusLO);
                unsigned char * hash = readClust(fp, bootEntry, startClus);
                //definitely my readfat has an issue OR ITS BECAUSE CONTIGUOUSLY ALLOCATED
                //printf("startClus: %d\n", startClus);
                size_t fileSize = (dirEntry.DIR_FileSize);
                size_t tracker = fileSize;
                if (fileSize > bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus){
                    hash = realloc(hash, fileSize);
                    if (hash == NULL){
                        printf("Error: Cannot allocate memory.\n");
                        fclose(fp);
                        exit(1);
                    }
                    tracker = bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus;
                }
                int clustSize = fileSize/(bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus)+(fileSize%(bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus)!=0);
                for (int i = 1; i < clustSize; ++i){
                    unsigned char * temp = readClust(fp, bootEntry, startClus+i);
                    if (fileSize-tracker < bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus){
                        memcpy(hash+tracker, temp, fileSize-tracker);
                        tracker += fileSize-tracker;
                        //printf("fileSize-tracker: %ld\n", fileSize-tracker);
                    }else {
                        memcpy(hash+tracker, temp, bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus);
                        tracker += bootEntry.BPB_BytsPerSec * bootEntry.BPB_SecPerClus;
                        //printf("tracker incremented by a whole cluster\n");
                    }
                    free(temp);
                }
                //printf("final tracker: %ld\n", tracker);
                unsigned char * swag = malloc(SHA_DIGEST_LENGTH);
                if (swag == NULL){
                    free(swag);
                    printf("Error: Cannot allocate memory.\n");
                    exit(1);
                }
                SHA1(hash, fileSize, swag);
                char * swagHex = malloc(SHA_DIGEST_LENGTH*2+1);
                if (swagHex == NULL){
                    free(swagHex);
                    printf("Error: Cannot allocate memory.\n");
                    exit(1);
                }
                swagHex[SHA_DIGEST_LENGTH*2] = '\0';
                for (size_t i = 0; i < SHA_DIGEST_LENGTH; i++) {
                    snprintf(&swagHex[i * 2], 3, "%02x", swag[i]);
                }
                //printf("swagHex: %s\n", swagHex);
                if (strcmp((char*)targetHash, swagHex)==0){
                    //IMPLEMENT WRITING/RECOVERING
                    //printf("target hash and swagHex same\n");
                    free(hash);
                    free(swag);
                    firstSectorOfCluster = ((rootClus - 2) * bootEntry.BPB_SecPerClus) + bootEntry.BPB_RsvdSecCnt + 
                    (bootEntry.BPB_NumFATs * bootEntry.BPB_FATSz32);
                    dirOffset = (firstSectorOfCluster * bootEntry.BPB_BytsPerSec) + (i * sizeof(DirEntry));
                    
                    dir_fileSize = dirEntry.DIR_FileSize;
                    found++;
                    break;
                }
                free(hash);
                free(swag);
            }
        }
        free(clustBuff);
        rootClus = readFat(fp, bootEntry, rootClus);
        //printf("rootClus: %d\n", rootClus);
    }while (!endOfClust(rootClus));

    if (found == 1){
        fseek(fp, dirOffset, SEEK_SET);
        fwrite(&filename[0],1,1,fp);
        if (dir_fileSize!=0){
            unsigned int fileSize = (dir_fileSize/bootEntry.BPB_BytsPerSec)/bootEntry.BPB_SecPerClus;
            for (int i = 0; i < fileSize; ++i){
                updateFat(fp, bootEntry, startClus, startClus+1);
                startClus++;
            }
            updateFat(fp, bootEntry, startClus, 0x0FFFFFFF);
        }

        printf("%s: successfully recovered with SHA-1\n", filename);
    }
    else if (found == 0){
        printf("%s: file not found\n", filename);
    }

    fclose(fp);
}



int main(int argc, char *argv[]) {
    int opt;
    char * diskName = NULL;
    diskName = argv[1];
    FILE * fp = fopen(diskName, "r+b");
    if (fp == NULL){
        print_usage();
        exit(0);
    }

    //milestone 1
    if ((opt = getopt(argc, argv, "ilr:R:s:"))!= -1){
        switch(opt){
            case 'i':
                //milestone 2
                print_fs(fp);
                break;
            case 'l':
                //milestone 3
                list_dir(fp);
                break;
            case 'r':
                //milestone 7
                if (strcmp(argv[argc-2], "-s")==0){
                    shaRecover(fp, argv[3], (unsigned char*)argv[argc-1]);
                    break;
                }
                //milestone 4
                recoverRegFiles(fp, argv[3]);
                break;
            case 'R':
                //handle R
                break;
            case 's':
                //handle s  
                printf("hit -s\n");
                break;
        }
    }
    else{
        print_usage();
    }
    
    return 0;
}
