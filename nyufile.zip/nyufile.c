#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>

#pragma pack(push,1)
typedef struct BootEntry {
  unsigned char  BS_jmpBoot[3];     // Assembly instruction to jump to boot code
  unsigned char  BS_OEMName[8];     // OEM Name in ASCII
  unsigned short BPB_BytsPerSec;    // Bytes per sector. Allowed values include 512, 1024, 2048, and 4096
  unsigned char  BPB_SecPerClus;    // Sectors per cluster (data unit). Allowed values are powers of 2, but the cluster size must be 32KB or smaller
  unsigned short BPB_RsvdSecCnt;    // Size in sectors of the reserved area
  unsigned char  BPB_NumFATs;       // Number of FATs
  unsigned short BPB_RootEntCnt;    // Maximum number of files in the root directory for FAT12 and FAT16. This is 0 for FAT32
  unsigned short BPB_TotSec16;      // 16-bit value of number of sectors in file system
  unsigned char  BPB_Media;         // Media type
  unsigned short BPB_FATSz16;       // 16-bit size in sectors of each FAT for FAT12 and FAT16. For FAT32, this field is 0
  unsigned short BPB_SecPerTrk;     // Sectors per track of storage device
  unsigned short BPB_NumHeads;      // Number of heads in storage device
  unsigned int   BPB_HiddSec;       // Number of sectors before the start of partition
  unsigned int   BPB_TotSec32;      // 32-bit value of number of sectors in file system. Either this value or the 16-bit value above must be 0
  unsigned int   BPB_FATSz32;       // 32-bit size in sectors of one FAT
  unsigned short BPB_ExtFlags;      // A flag for FAT
  unsigned short BPB_FSVer;         // The major and minor version number
  unsigned int   BPB_RootClus;      // Cluster where the root directory can be found
  unsigned short BPB_FSInfo;        // Sector where FSINFO structure can be found
  unsigned short BPB_BkBootSec;     // Sector where backup copy of boot sector is located
  unsigned char  BPB_Reserved[12];  // Reserved
  unsigned char  BS_DrvNum;         // BIOS INT13h drive number
  unsigned char  BS_Reserved1;      // Not used
  unsigned char  BS_BootSig;        // Extended boot signature to identify if the next three values are valid
  unsigned int   BS_VolID;          // Volume serial number
  unsigned char  BS_VolLab[11];     // Volume label in ASCII. User defines when creating the file system
  unsigned char  BS_FilSysType[8];  // File system type label in ASCII
} BootEntry;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct DirEntry {
  unsigned char  DIR_Name[11];      // File name
  unsigned char  DIR_Attr;          // File attributes
  unsigned char  DIR_NTRes;         // Reserved
  unsigned char  DIR_CrtTimeTenth;  // Created time (tenths of second)
  unsigned short DIR_CrtTime;       // Created time (hours, minutes, seconds)
  unsigned short DIR_CrtDate;       // Created day
  unsigned short DIR_LstAccDate;    // Accessed day
  unsigned short DIR_FstClusHI;     // High 2 bytes of the first cluster address
  unsigned short DIR_WrtTime;       // Written time (hours, minutes, seconds
  unsigned short DIR_WrtDate;       // Written day
  unsigned short DIR_FstClusLO;     // Low 2 bytes of the first cluster address
  unsigned int   DIR_FileSize;      // File size in bytes. (0 for directories)
} DirEntry;
#pragma pack(pop)

void print_usage(){
    printf( "Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a contiguous file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
}

bool endOfClust(unsigned int clusterNumber){
    return clusterNumber >= 0x0FFFFFF8;
}

unsigned int readFat(FILE * disk, BootEntry bootEntry, unsigned int clustNum){
    unsigned int FATOffset = clustNum * 4;
    unsigned int FATSector = bootEntry.BPB_RsvdSecCnt + (FATOffset / bootEntry.BPB_BytsPerSec);
    unsigned int FATEntryOffset = FATOffset % bootEntry.BPB_BytsPerSec;

    fseek(disk, (FATSector * bootEntry.BPB_BytsPerSec) + FATEntryOffset, SEEK_SET);

    unsigned int FATEntry;
    fread(&FATEntry, sizeof(FATEntry), 1, disk);
    FATEntry &= 0x0FFFFFFF;


    //returns address of next cluster
    return FATEntry;
}

unsigned char * readClust(FILE * fp,BootEntry bootEntry, unsigned int clustNum){
    unsigned int sect = bootEntry.BPB_RsvdSecCnt+(bootEntry.BPB_NumFATs*bootEntry.BPB_FATSz32); //calcualtes reserved sectors + fat area
    unsigned int clustSect = ((clustNum-2)*bootEntry.BPB_SecPerClus)+sect;
    unsigned int clustBytes = bootEntry.BPB_SecPerClus * bootEntry.BPB_BytsPerSec;

    unsigned char * clustBuff = malloc(clustBytes);
    if (clustBuff == NULL){
        printf("Error: Cannot allocate memory.\n");
        fclose(fp);
        exit(1);
    }

    fseek(fp, clustSect*bootEntry.BPB_BytsPerSec, SEEK_SET);
    fread(clustBuff, clustBytes, 1, fp);

    return clustBuff;
}

unsigned int combAdd(unsigned short hi, unsigned short lo){
    unsigned int combined = hi;
    combined <<= 16;
    combined |= lo;
    return combined;
}


void print_fs(FILE * fp){
    BootEntry bootEntry;

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }

    fclose(fp);
    printf("Number of FATs = %d\n", bootEntry.BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", bootEntry.BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n", bootEntry.BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", bootEntry.BPB_RsvdSecCnt);
}

void formatName(char * formatted, unsigned char * raw){
    
    int end = 7;
    while (end >=0 && raw[end] == ' '){
        end--;
    }

    strncpy(formatted,(const char*) raw, end+1);
    formatted[end+1] = '\0';

    bool ext = false;
    for (int i = 8; i < 11; ++i){
        if (raw[i] != ' '){
            ext = true;
            break;
        }
    }

    if (ext){
        int extEnd = 10;
        while (extEnd >= 8 && raw[extEnd] == ' '){
            extEnd--;
        }
        strcat(formatted, ".");
        strncat(formatted, (const char*)raw+8, extEnd-7);
    }
}

void list_dir(FILE * fp){
    BootEntry bootEntry;

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }

    //init to start of the FAT area
    unsigned int rootClus = bootEntry.BPB_RootClus;

    //process
    int count = 0;
    do {
        unsigned char* clustBuff = readClust(fp, bootEntry, rootClus);
        DirEntry * dirEntries = (DirEntry*)clustBuff;
        int entries = bootEntry.BPB_BytsPerSec / sizeof(DirEntry);

        for (int i = 0; i < entries; ++i){
            DirEntry dirEntry = dirEntries[i];
            if (dirEntry.DIR_Name[0] == 0x00){
                break;
            }else if (dirEntry.DIR_Name[0] == 0xE5){
                continue;
            }

            unsigned int startClus = combAdd(dirEntry.DIR_FstClusHI, dirEntry.DIR_FstClusLO);
            char format[10];
            formatName(format, dirEntry.DIR_Name);
            if (startClus == 0){
                printf("%s (size = %d)\n", format,dirEntry.DIR_FileSize);
            }
            else if ((dirEntry.DIR_Attr &0x10) == 0x10){
                printf("%s/ (starting cluster = %u)\n", format, startClus);
            }else{
                printf("%s (size = %d, starting cluster = %d)\n", format, dirEntry.DIR_FileSize, startClus);
            }
            count++;
        }
        free(clustBuff);
        rootClus = readFat(fp, bootEntry, rootClus);

    }while (!endOfClust(rootClus));

    printf("Total number of entries = %d\n", count);

    fclose(fp);
}

void updateFat(FILE *fp, BootEntry bootEntry, unsigned int clustNum, unsigned int nextClust){
    unsigned int FATOffset = clustNum * 4;
    unsigned int FATSector = bootEntry.BPB_RsvdSecCnt + (FATOffset / bootEntry.BPB_BytsPerSec);
    unsigned int FATEntryOffset = FATOffset % bootEntry.BPB_BytsPerSec;

    long FATEntryPosition = (FATSector * bootEntry.BPB_BytsPerSec) + FATEntryOffset;
    fseek(fp, FATEntryPosition, SEEK_SET);

    unsigned int currentFATEntry;
    fread(&currentFATEntry, sizeof(currentFATEntry), 1, fp);

    currentFATEntry = (currentFATEntry & 0xF0000000) | (nextClust & 0x0FFFFFFF);

    fseek(fp, FATEntryPosition, SEEK_SET);
    fwrite(&currentFATEntry, sizeof(currentFATEntry), 1, fp);
}

void recoverRegFiles(FILE *fp, char * filename){

    BootEntry bootEntry;

    if (fread(&bootEntry, sizeof(BootEntry), 1, fp) != 1){
        printf("Error: Cannot read file system image.\n");
        fclose(fp);
        exit(1);
    }
    
    //init to start of the FAT area
    unsigned int rootClus = bootEntry.BPB_RootClus;
    //bool found = false;

    //process
    do {
        unsigned char* clustBuff = readClust(fp, bootEntry, rootClus);
        DirEntry * dirEntries = (DirEntry*)clustBuff;
        int entries = bootEntry.BPB_BytsPerSec / sizeof(DirEntry);

        for (int i = 0; i < entries; ++i){
            DirEntry dirEntry = dirEntries[i];
            if (dirEntry.DIR_Name[0] == 0x00){
                printf("%s: file not found\n", filename);
                break;
            }else if (dirEntry.DIR_Name[0] == 0xE5){
                char name[11];
                formatName(name, dirEntry.DIR_Name);
                //printf("found a deleted file\n");
               // printf("name after formatting: %s||\n", name);
                //printf("filename: %s||\n", filename);
                if (strcmp(name+1,filename+1)==0){
                    //IMPLEMENT WRITING/RECOVERING

                    unsigned int firstSectorOfCluster = ((rootClus - 2) * bootEntry.BPB_SecPerClus) + bootEntry.BPB_RsvdSecCnt + (bootEntry.BPB_NumFATs * bootEntry.BPB_FATSz32);
                    long dirOffset = (firstSectorOfCluster * bootEntry.BPB_BytsPerSec) + (i * sizeof(DirEntry));

                    fseek(fp, dirOffset, SEEK_SET);
                    fwrite(&filename[0],1,1,fp);

                    unsigned int startClus = combAdd(dirEntry.DIR_FstClusHI, dirEntry.DIR_FstClusLO);

                    if (dirEntry.DIR_FileSize!=0){
                        /*unsigned int nextClus = readFat(fp, bootEntry, startClus);
                        unsigned int prevClus = startClus;
                        while (!endOfClust(nextClus)){
                            updateFat(fp, bootEntry, prevClus, 0);
                            prevClus = nextClus;
                            nextClus = readFat(fp, bootEntry, nextClus);
                        }*/
                        updateFat(fp, bootEntry, startClus, 0x0FFFFFFF);
                    }

                    printf("%s: successfully recovered\n", filename);
                    break;
                }
            }
        }
        free(clustBuff);
        rootClus = readFat(fp, bootEntry, rootClus);

    }while (!endOfClust(rootClus));


    fclose(fp);
}


int main(int argc, char *argv[]) {
    int opt;
    char * diskName = NULL;
    diskName = argv[1];
    FILE * fp = fopen(diskName, "r+b");
    if (fp == NULL){
        print_usage();
        exit(0);
    }

    //milestone 1
    if ((opt = getopt(argc, argv, "ilr:R:s:"))!= -1){
        switch(opt){
            case 'i':
                //milestone 2
                print_fs(fp);
                break;
            case 'l':
                //milestone 3
                list_dir(fp);
                break;
            case 'r':
                //milestone 4
                if (strcmp(argv[argc-1], "sha1")==0){
                    break;
                }
                recoverRegFiles(fp, argv[3]);
                break;
            case 'R':
                //handle R
                break;
            case 's':
                //handle s  
                printf("hit -s\n");
                break;
        }
    }
    else{
        print_usage();
    }
    
    return 0;
}
